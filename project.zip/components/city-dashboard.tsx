'use client'

import { useMemo, useState } from 'react'
import {
  Activity, ArrowDownRight, ArrowRight, ArrowUpRight, Bus, CalendarDays,
  Check, ChevronDown, Clock3, CloudSun, GraduationCap, HeartPulse, MapPin,
  Menu, Search, Shield, TrainFront, Trees, Waves,
} from 'lucide-react'

const categories = ['All services', 'Transport', 'Healthcare', 'Education', 'Public services']
const services = [
  { name: 'Metro & rail', detail: '4 lines · service running normally', tag: 'Every 4 min', icon: TrainFront, category: 'Transport', tone: 'blue' },
  { name: 'City bus network', detail: '128 routes across the city', tag: 'Live updates', icon: Bus, category: 'Transport', tone: 'green' },
  { name: 'Hospitals & clinics', detail: 'Find care near you, 24/7', tag: '12 locations', icon: HeartPulse, category: 'Healthcare', tone: 'rose' },
  { name: 'Schools & learning', detail: 'Schools, libraries and programs', tag: '46 locations', icon: GraduationCap, category: 'Education', tone: 'amber' },
  { name: 'City services', detail: 'Permits, waste and city help', tag: 'Online services', icon: Trees, category: 'Public services', tone: 'violet' },
]
const locations = [
  { name: 'Central City Hall', type: 'Civic services', distance: '0.4 mi', icon: Trees },
  { name: 'Northside Medical Center', type: 'Emergency · 24 hours', distance: '1.2 mi', icon: HeartPulse },
  { name: 'Riverside Central Station', type: 'Transit hub', distance: '1.6 mi', icon: TrainFront },
]

export default function CityDashboard() {
  const [active, setActive] = useState('All services')
  const [query, setQuery] = useState('')
  const visibleServices = useMemo(() => services.filter((item) =>
    (active === 'All services' || item.category === active) && `${item.name} ${item.detail}`.toLowerCase().includes(query.toLowerCase())), [active, query])

  return (
    <main className="city-app">
      <header className="topbar">
        <a className="brand" href="#home" aria-label="Civicly home"><span className="brand-mark"><Activity /></span><span>CIVIC<span className="brand-light">LY</span></span></a>
        <nav className="main-nav" aria-label="Main navigation">
          <a className="nav-active" href="#home">Overview</a><a href="#services">City services</a><a href="#locations">Explore city</a>
        </nav>
        <div className="top-actions"><button className="weather-pill" aria-label="Current weather, sunny and 22 degrees"><CloudSun /><span>22° <small>Sunny</small></span></button><button className="menu-button" aria-label="Open menu"><Menu /></button><button className="avatar" aria-label="Your profile">JD</button></div>
      </header>

      <section className="hero" id="home">
        <div className="hero-image" />
        <div className="hero-shade" />
        <div className="hero-content">
          <div className="eyebrow"><span className="live-dot" /> YOUR CITY, IN REAL TIME</div>
          <h1>A better city<br />starts <em>together.</em></h1>
          <p>Your everyday guide to a more connected, livable city.</p>
          <a className="hero-link" href="#services">Explore city services <ArrowRight /></a>
        </div>
        <div className="hero-note"><span className="note-icon"><MapPin /></span><span><b>Riverside District</b><small>Downtown · 9:41 AM</small></span><ChevronDown /></div>
        <div className="hero-pagination"><span /><span /><span /></div>
      </section>

      <div className="content-wrap">
        <section className="status-strip" aria-label="City status">
          <div className="status-heading"><span className="status-live" /> CITY STATUS <span className="status-divider">·</span> <span className="status-updated">Updated just now</span></div>
          <div className="status-items"><span><Bus /> Transit <b>Running smoothly</b></span><span><Waves /> Air quality <b>Good · 32 AQI</b></span><span><Shield /> City services <b>All operational</b></span></div>
        </section>

        <section className="section services-section" id="services">
          <div className="section-heading"><div><span className="kicker">MADE FOR EVERY DAY</span><h2>City services</h2><p>Everything you need to get around and get things done.</p></div><a className="text-link" href="#locations">View all services <ArrowRight /></a></div>
          <div className="service-toolbar"><div className="filters" role="tablist" aria-label="Filter city services">{categories.map((category) => <button role="tab" aria-selected={active === category} className={active === category ? 'filter active-filter' : 'filter'} key={category} onClick={() => setActive(category)}>{category}</button>)}</div><label className="search-box"><Search /><span className="sr-only">Search city services</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search services" /></label></div>
          <div className="service-grid">{visibleServices.length ? visibleServices.map(({ name, detail, tag, icon: Icon, tone }) => <a className="service-card" href="#locations" key={name}><div className={`service-icon ${tone}`}><Icon /></div><span className="service-arrow"><ArrowUpRight /></span><h3>{name}</h3><p>{detail}</p><div className="service-meta"><span className="mini-check"><Check /></span>{tag}</div></a>) : <p className="empty-state">No services match your search. Try another keyword.</p>}</div>
        </section>

        <section className="section data-section" aria-labelledby="data-title">
          <div className="section-heading data-heading"><div><span className="kicker">THE CITY AT A GLANCE</span><h2 id="data-title">A little more connected.</h2></div><div className="period-select">Last 30 days <ChevronDown /></div></div>
          <div className="stats-grid">
            <article className="stat-card"><div className="stat-top"><span>PUBLIC TRANSIT RIDERS</span><span className="stat-icon"><TrainFront /></span></div><div className="stat-value">2.4<span>m</span></div><div className="stat-foot"><span className="trend-up"><ArrowUpRight /> 8.2%</span> vs. previous month</div><div className="sparkline teal"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div></article>
            <article className="stat-card"><div className="stat-top"><span>GREEN SPACE</span><span className="stat-icon"><Trees /></span></div><div className="stat-value">34<span>%</span></div><div className="stat-foot"><span className="trend-up"><ArrowUpRight /> 2.1%</span> city-wide coverage</div><div className="progress-track"><span /></div><div className="progress-label"><span>City target: 40%</span><span>34 of 40%</span></div></article>
            <article className="stat-card"><div className="stat-top"><span>AVERAGE COMMUTE</span><span className="stat-icon"><Clock3 /></span></div><div className="stat-value">26<span> min</span></div><div className="stat-foot"><span className="trend-down"><ArrowDownRight /> 3 min</span> faster this month</div><div className="commute-bars"><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/><i/></div><div className="progress-label"><span>Weekday average</span><span>↓ 10% this year</span></div></article>
          </div>
        </section>

        <section className="section lower-grid" id="locations">
          <div className="locations-panel"><div className="section-heading compact"><div><span className="kicker">AROUND YOU</span><h2>Important places</h2></div><a className="text-link" href="#locations">Open map <ArrowRight /></a></div><div className="location-list">{locations.map(({ name, type, distance, icon: Icon }) => <a className="location-row" href="https://maps.google.com" key={name}><span className="location-icon"><Icon /></span><span className="location-copy"><b>{name}</b><small>{type}</small></span><span className="distance">{distance}</span><ArrowRight className="row-arrow" /></a>)}</div></div>
          <aside className="emergency-card"><div className="emergency-top"><span className="emergency-icon"><Shield /></span><span className="emergency-badge"><span /> ALL CLEAR</span></div><span className="kicker">HERE WHEN IT MATTERS</span><h2>Emergency<br />information</h2><p>Know where to go and who to call. Help is always close by.</p><a href="tel:911" className="emergency-link"><span>Emergency services</span><b>Call 911 <ArrowUpRight /></b></a><a className="emergency-details" href="#locations">View safety resources <ArrowRight /></a></aside>
        </section>

        <section className="community-banner"><span className="calendar-icon"><CalendarDays /></span><div><b>Good things happen when we show up.</b><p>Discover what&apos;s happening in your neighborhood this week.</p></div><a href="#services">Explore events <ArrowRight /></a></section>
        <footer className="footer"><a className="brand footer-brand" href="#home"><span className="brand-mark"><Activity /></span><span>CIVIC<span className="brand-light">LY</span></span></a><span>Made for the people who make this city.</span><a href="#home">Accessibility <span>·</span> Contact the city</a></footer>
      </div>
    </main>
  )
}
