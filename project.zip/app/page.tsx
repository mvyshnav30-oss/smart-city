import CityDashboard from '@/components/city-dashboard'

export default function Page() {
  return <CityDashboard />
}
